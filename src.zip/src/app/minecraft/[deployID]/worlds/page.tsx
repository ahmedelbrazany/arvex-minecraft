"use client";

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useWebSocket } from '@/context/WebSocketContext';
import McSideBar from '@/components/McSideBar';
import Image from 'next/image';

interface ServerDetails {
  serverName: string;
  serverID: string;
}

interface FileData {
  [key: string]: {
    isDir: boolean;
    content?: string;
  };
}

export default function WorldsPage() {
  const { deployID } = useParams();
  const { socket, isConnected } = useWebSocket();
  const [serverDetails, setServerDetails] = useState<ServerDetails>({ serverName: '', serverID: '' });
  const [currentPath, setCurrentPath] = useState<string[]>([]);
  const [files, setFiles] = useState<FileData>({});
  const [isLoading, setIsLoading] = useState(true);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  useEffect(() => {
    if (!isConnected || !socket) return;

    const fetchServerDetails = async () => {
      try {
        const response = await fetch(`/api/v1/deploys/${deployID}?only_data=1`);
        const data = await response.json();
        setServerDetails({
          serverName: data.name,
          serverID: data._id
        });
      } catch (error) {
        console.error('Error fetching server details:', error);
      }
    };

    fetchServerDetails();

    socket.onmessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        if (data.event === 'files') {
          const filteredFiles = filterFiles(data.data);
          setFiles(filteredFiles);
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.send(JSON.stringify({ event: 'files', data: {} }));
  }, [isConnected, socket, deployID]);

  const filterFiles = (files: FileData) => {
    const ignoredFiles = [
      'banned-ips.json', 'banned-players.json', 'BuildTools.log.txt',
      'eula.txt', 'ops.json', 'permissions.yml', 'usercache.json',
      'whitelist.json', 'logs', 'work', 'plugins'
    ];
    
    const filtered = { ...files };
    for (const key of ignoredFiles) delete filtered[key];
    for (const key of Object.keys(filtered)) {
      if (key.endsWith('.mca')) delete filtered[key];
    }
    return filtered;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await fetch(`/api/upload?path=${currentPath.join('/') || '/'}`, {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        socket?.send(JSON.stringify({ event: 'getFiles', data: currentPath.join('/') }));
      }
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  };

  const navigateToFolder = (folderName: string) => {
    const newPath = [...currentPath, folderName];
    setCurrentPath(newPath);
    socket?.send(JSON.stringify({
      event: 'getFiles',
      data: newPath.join('/')
    }));
  };

  const goBack = () => {
    if (currentPath.length > 0) {
      const newPath = currentPath.slice(0, -1);
      setCurrentPath(newPath);
      socket?.send(JSON.stringify({
        event: 'getFiles',
        data: newPath.join('/') || '/'
      }));
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <McSideBar 
        serverDetails={serverDetails} 
        deployID={deployID as string} 
        activePage="worlds" 
      />
      
      <div className="content">
        <div className="file-list">
          {Object.entries(files).map(([name, data]) => (
            <div key={name} className="file-item">
              <div className="file-icon">
                <Image
                  src={data.isDir ? '/assets/world.png' : '/assets/files.png'}
                  alt={data.isDir ? 'Folder' : 'File'}
                  width={32}
                  height={32}
                />
              </div>
              <div className="file-name">{name}</div>
              <button
                className="file-action"
                onClick={() => data.isDir ? navigateToFolder(name) : null}
              >
                {data.isDir ? 'Open Folder' : 'View File'}
              </button>
            </div>
          ))}
        </div>

        <div className="upload-section">
          <label className="upload-label">
            📂 Upload Files / Folders
            <input
              type="file"
              multiple
              onChange={handleFileUpload}
              className="upload-input"
            />
          </label>
          {uploadProgress > 0 && (
            <div className="progress-container">
              <div 
                className="progress-bar" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          )}
        </div>

        {currentPath.length > 0 && (
          <div className="navigation-buttons">
            <button className="back-button" onClick={goBack}>
              ⬅ Back
            </button>
            <button 
              className="delete-button"
              onClick={() => {
                if (confirm('⚠️ Are you sure you want to delete this folder?')) {
                  socket?.send(JSON.stringify({
                    event: 'deleteFile',
                    data: currentPath.join('/')
                  }));
                }
              }}
            >
              Remove Folder
            </button>
          </div>
        )}
      </div>
    </div>
  );
}